﻿using BankingSystem.Logic;

Account account;
var transaction = new Transaction();

Console.Write("Type of account ([c]hecking, [b]usiness, [s]avings):   ");
var amountType = char.Parse(Console.ReadLine()!);

switch (amountType)
{
    case 'c': account = new CheckingAccount(); break;
    case 'b': account = new BusinessAccount(); break;
    case 's': account = new SavingsAccount(); break;
    default: return;
}

Console.Write("Account number: ");
account.AccountNumber = Console.ReadLine()!;
Console.Write("Account holder: ");
account.AccountHolder = Console.ReadLine()!;
Console.Write("Current balance: ");
account.CurrentBalance = decimal.Parse(Console.ReadLine()!);
Console.Write("Transaction account number:");
transaction.AccountNumber = Console.ReadLine()!;
Console.Write("Transaction description: ");
transaction.Description = Console.ReadLine()!;
Console.Write("Transaction amount: ");
transaction.Amount = decimal.Parse(Console.ReadLine()!);
Console.WriteLine("Transaction timestap: ");
transaction.TimeStamp = DateTime.Parse(Console.ReadLine()!);


Console.Write("Transaction is ");
Console.WriteLine(account.IsAllowed(transaction) ? "allowed" : "not allowed");
