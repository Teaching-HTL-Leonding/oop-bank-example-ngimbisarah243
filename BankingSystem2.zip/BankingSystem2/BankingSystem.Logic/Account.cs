﻿namespace BankingSystem.Logic;
public abstract class Account
{
    public string AccountNumber { get; set; } = "";
    public string AccountHolder { get; set; } = "";
    public decimal CurrentBalance { get; set; } 

    public abstract bool IsAllowed(Transaction t);

}
