﻿namespace BankingSystem.Logic;
public class CheckingAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Amount > 10000) return false;
        if (t.AccountNumber != AccountNumber) return false;
        CurrentBalance += t.Amount;
        if (CurrentBalance > -10000 && CurrentBalance < 10000000) return true;
        return false;
    }
}

public class BusinessAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Amount > 100000) return false;
        CurrentBalance += t.Amount;
        if (t.AccountNumber != AccountNumber) return false;
        if (CurrentBalance > -1000000 && CurrentBalance < 100000000) return true;
        return false;
    }
}

public class SavingsAccount : Account
{
    public override bool IsAllowed(Transaction t)
    {
        if (t.Amount > 100000) return false;
        CurrentBalance += t.Amount;
        if (t.AccountNumber != AccountNumber) return false;
        if (CurrentBalance > 0 && CurrentBalance < 100000000) return true;
        return false;
    }
}