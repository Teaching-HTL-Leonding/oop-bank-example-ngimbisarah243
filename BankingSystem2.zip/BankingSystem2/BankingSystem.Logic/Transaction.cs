﻿namespace BankingSystem.Logic
{
    public class Transaction
    {
        public string AccountNumber { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime TimeStamp { get; set; }
        public decimal Amount { get; set; }

    }

}