﻿using BankingSystem.Logic;

Account account;

var accounts = File.ReadAllLines("Accounts.txt");
var transactions = File.ReadAllLines("Transactions.txt");

int i = 1;
var transaction = new Transaction();


do
{

    char accountType = Convert.ToChar(accounts[i].Split(';')[0]);

    switch (accountType)
    {
        case 'c': account = new CheckingAccount(); break;
        case 'b': account = new BusinessAccount(); break;
        case 's': account = new SavingsAccount(); break;
        default: return;
    }
    account.AccountNumber = accounts[i].Split(';')[1];
    account.AccountHolder = accounts[i].Split(';')[2];
    account.CurrentBalance = Convert.ToDecimal(accounts[i].Split(';')[3]); 

    transaction.AccountNumber = transactions[i].Split(';')[0];
    transaction.Description= transactions[i].Split(';')[1];
    transaction.Amount = decimal.Parse(transactions[i].Split(';')[2]);

    if (account.IsAllowed(transaction))
    {
        account.T
    }

} while (i < accounts.Length - 1 || account.IsAllowed(transaction));

